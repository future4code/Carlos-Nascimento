```function calculaPrecoTotal(quantidade) {
  return quantidade >= 12 ? quantidade : quantidade * 1.3
}```
